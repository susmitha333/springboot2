package StudentModel;

public class studentModel {
	protected int id;
	protected String AssignmentCategory;
	protected String Weight;
 
		public studentModel() {
		super();
	}

		public studentModel( String assignmentCategory, String weight) {
		super();
		this.AssignmentCategory = assignmentCategory;
		this.Weight = weight;
	}
	
		public studentModel(int id, String assignmentCategory, String weight) {
		super();
		this.id = id;
		this.AssignmentCategory = assignmentCategory;
		this.Weight = weight;
	}
		public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAssignmentCategory() {
		return AssignmentCategory;
	}
	public void setAssignmentCategory(String assignmentCategory) {
		AssignmentCategory = assignmentCategory;
	}
	public String getWeight() {
		return Weight;
	}
	public void setWeight(String weight) {
		Weight = weight;
	}
	@Override
	public String toString() {
		return "studentModel [id=" + id + ", AssignmentCategory=" + AssignmentCategory + ", Weight=" + Weight + "]";
	}	

}

