package junittest;

public class cas2 {
	public String name(String a ,String b) {
		return a+b;
		
	}

}
