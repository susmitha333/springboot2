package junittest;

import static org.junit.Assert.*;

import org.junit.Test;

public class testcase {

	@Test
	public void test() {
		knowledgeontestacases test=new knowledgeontestacases();
				int re=test.addint(10, 20);
		assertEquals(30,re);
	}

}
