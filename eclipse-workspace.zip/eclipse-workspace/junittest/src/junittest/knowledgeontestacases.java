package junittest;

public class knowledgeontestacases {
	public int addint(int a, int b) {
		return a+b;
		
	}
	

}
