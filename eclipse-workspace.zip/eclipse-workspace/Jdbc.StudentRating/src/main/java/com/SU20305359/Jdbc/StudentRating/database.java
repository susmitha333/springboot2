package com.SU20305359.Jdbc.StudentRating;

public class database {
	private int id;
	private int age;
	private String first;
	private String last;

}
