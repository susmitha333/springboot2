package Core.Java;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StudentData {

//	public List<String[]> readData() throws IOException { 
//	    int count = 0;
//	    String file = "C:\\Users\\surya\\Desktop\\susmitha\\StudentData.csv";
//	    List<String[]> content = new ArrayList<>();
//	    try(BufferedReader br = new BufferedReader(new FileReader(file))) {
//	        String line = "";
//	        while ((line = br.readLine()) != null) {
//	            content.add(line.split(";"));
//	        }
//	    } catch (FileNotFoundException e) {
//	      //Some error logging
//	    }
//	    return content;
//	}
 public static void main(String[] args) throws IOException {
	 
//	 StudentData ob=new StudentData();
//	List<String[]> haa= ob.readData();
//	System.out.println(haa);
	 
	     final String SEPARATOR = ",";
  try
   {
	  
	 String line = "";
     BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\surya\\Desktop\\susmitha\\StudentData.csv"));

     while ((line = br.readLine()) != null) 
     { 	 
	   String[] tokens = line.split(SEPARATOR);
	  
	   System.out.println("Name:"+tokens[0]+"\tSubject:"+tokens[1]+"\t\tassignament:"+tokens[2]+"\t\tDateOfSubmission:"+tokens[3]+"\t\tpoints:"+tokens[4]);

//	   List<Float> pricesList =  productsList.stream()  
//               .filter(p ->p.price> 30000)   // filtering price  
////               .map(pm ->pm.price)          // fetching price  
//               .collect(Collectors.toList());  
//   System.out.println(pricesList);  
	   
	   
       }
      } catch (IOException e)
          {
        	
           }
  
 }
	 

}
